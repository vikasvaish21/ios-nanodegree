//
//  meme.swift
//  project2
//
//  Created by vikas on 23/06/19.
//  Copyright © 2019 project1. All rights reserved.
//

import UIKit

struct meme
{
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}

