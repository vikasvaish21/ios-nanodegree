//
//  MemeCollectionViewCell.swift
//  MemeMe 2.0
//
//  Created by vikas on 29/06/19.
//  Copyright © 2019 project1. All rights reserved.
//

import Foundation
import UIKit

class MemeCollectionViewCell: UICollectionViewCell

{
    
    @IBOutlet weak var labelView: UILabel!
    @IBOutlet weak var imageView: UIImageView!
}
