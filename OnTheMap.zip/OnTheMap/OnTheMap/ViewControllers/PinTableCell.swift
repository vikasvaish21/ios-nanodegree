//
//  PinTableCell.swift
//  OnTheMap
//
//  Created by vikas on 19/07/19.
//  Copyright © 2019 project1. All rights reserved.
//

import Foundation
import UIKit

class PinTableCell: UITableViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var mediaLabel: UILabel!
    
}

