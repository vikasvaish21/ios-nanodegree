//
//  StudentLocationPutResponse.swift
//  OnTheMap
//
//  Created by vikas on 18/07/19.
//  Copyright © 2019 project1. All rights reserved.
//

import Foundation
struct StudentLocationPutResponse:Codable {
    let createdAt: String?
    let objectId: String?
}
