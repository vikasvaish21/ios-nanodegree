//
//  meme.swift
//  MemeMe 2.0
//
//  Created by vikas on 28/06/19.
//  Copyright © 2019 project1. All rights reserved.
//

import UIKit

struct Meme{
    var topText :String
    var bottomText :String
    var originalImage :UIImage
    var memedImage :UIImage
}
